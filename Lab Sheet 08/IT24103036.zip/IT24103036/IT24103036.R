setwd("C:\\Users\\MSI\\Desktop\\IT24103036")
getwd()



weights_data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
attach(weights_data)

pop_mean <- mean(Weight.kg.)

n <- length(Weight.kg.)
sample_var <- var(Weight.kg.)
pop_var <- sample_var * (n - 1) / n
pop_sd <- sqrt(pop_var)

print("--- Question 1 Results ---")
print(paste("Population Mean:", pop_mean))
print(paste("Population Standard Deviation:", pop_sd))




num_samples <- 25
sample_size <- 6

set.seed(123)
samples_matrix <- replicate(num_samples, sample(Weight.kg., sample_size, replace = TRUE))

sample_means <- apply(samples_matrix, 2, mean)
sample_sds <- apply(samples_matrix, 2, sd)

results_q2 <- data.frame(
  Sample_Number = 1:num_samples,
  Mean = sample_means,
  Standard_Deviation = sample_sds
)

print("--- Question 2 Results ---")
print(results_q2)




mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)
true_standard_error <- pop_sd / sqrt(sample_size)

print("--- Question 3 Results ---")
print(paste("Mean of the Sample Means:", mean_of_sample_means))
print(paste("Standard Deviation of the Sample Means (Observed SE):", sd_of_sample_means))

cat("\n--- Relationship ---\n")
cat("Population Mean:", pop_mean, "\n")
cat("Theoretical Standard Error (SE):", true_standard_error, "\n")


detach(weights_data)